import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, Clock, Shield, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/components/AuthProvider";
import heroImage from "@/assets/emergency-hero.jpg";

const Home = () => {
  const navigate = useNavigate();
  const { signOut, user } = useAuth();

  const handleEmergencyRequest = () => {
    navigate("/traffic-simulation");
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-soft border-b">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-emergency rounded-lg">
                <AlertTriangle className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-bold text-foreground">Emergency Traffic</h1>
                <p className="text-sm text-muted-foreground">Clearance System</p>
              </div>
            </div>
            <Button
              variant="ghost"
              onClick={handleSignOut}
              className="p-2"
              title="Sign Out"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <div className="max-w-md mx-auto px-4 py-6 space-y-6">
        <div className="relative rounded-xl overflow-hidden shadow-emergency">
          <img
            src={heroImage}
            alt="Emergency traffic clearance system"
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-4 text-white">
            <h2 className="text-xl font-bold mb-1">
              Emergency Traffic Clearance
            </h2>
            <p className="text-sm opacity-90">
              Instantly coordinate with traffic systems to clear emergency vehicle routes
            </p>
          </div>
        </div>

        {/* Main Action Button */}
        <div className="flex justify-center">
          <Button
            onClick={handleEmergencyRequest}
            className="bg-gradient-emergency hover:shadow-glow pulse-emergency text-primary-foreground text-lg px-8 py-6 rounded-xl font-semibold transition-all duration-300"
            size="lg"
          >
            <AlertTriangle className="mr-2 h-6 w-6" />
            Request Emergency Clearance
          </Button>
        </div>

        {/* Info Panel */}
        <Card className="shadow-soft border-primary/20">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-2 bg-secondary/20 rounded-lg mt-1">
                <Shield className="h-5 w-5 text-secondary" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-2">How it works</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  Send alert to nearby traffic lights and vehicles to automatically 
                  clear the optimal route for emergency response.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Status Cards */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="shadow-soft">
            <CardContent className="p-3 text-center">
              <div className="text-xl font-bold text-primary mb-1">24/7</div>
              <div className="text-xs text-muted-foreground">System Active</div>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardContent className="p-3 text-center">
              <div className="text-xl font-bold text-secondary mb-1">&lt;30s</div>
              <div className="text-xs text-muted-foreground">Avg Response</div>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardContent className="p-3 text-center">
              <div className="text-xl font-bold text-green-600 mb-1">99.9%</div>
              <div className="text-xs text-muted-foreground">Reliability</div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Access */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => navigate("/dashboard")}
            className="flex-1"
          >
            Dashboard
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("/help")}
            className="flex-1"
          >
            Help & Safety
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Home;