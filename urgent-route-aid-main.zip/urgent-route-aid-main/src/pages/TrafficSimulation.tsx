import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Car, MapPin, Navigation, Circle, Volume2, VolumeX } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useState, useRef } from "react";

// Voice navigation messages
const voiceMessages = [
  "Emergency clearance request sent. Please proceed to the route.",
  "Traffic system connected. Route optimization in progress.",
  "Turn right at the next intersection. Traffic light is green.",
  "Continue straight for 500 meters. Traffic signal overridden.",
  "Route cleared successfully. Emergency vehicle has arrived at destination."
];

const TrafficSimulation = () => {
  const navigate = useNavigate();
  const [simulationStep, setSimulationStep] = useState(0);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [isPlaying, setIsPlaying] = useState(false);
  const speechSynthRef = useRef<SpeechSynthesisUtterance | null>(null);
  const [trafficLights, setTrafficLights] = useState([
    { id: 1, x: 20, y: 30, status: 'red' },
    { id: 2, x: 50, y: 45, status: 'red' },
    { id: 3, x: 80, y: 60, status: 'red' },
    { id: 4, x: 35, y: 70, status: 'red' },
  ]);

  // Voice synthesis function
  const speakMessage = (message: string) => {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    
    // Cancel any ongoing speech
    window.speechSynthesis.cancel();
    
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.rate = 0.9;
    utterance.pitch = 1;
    utterance.volume = 0.8;
    
    utterance.onstart = () => setIsPlaying(true);
    utterance.onend = () => setIsPlaying(false);
    utterance.onerror = () => setIsPlaying(false);
    
    speechSynthRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Toggle voice navigation
  const toggleVoice = () => {
    if (voiceEnabled && isPlaying) {
      window.speechSynthesis.cancel();
      setIsPlaying(false);
    }
    setVoiceEnabled(!voiceEnabled);
  };

  useEffect(() => {
    if (simulationStep > 0) {
      const timer = setTimeout(() => {
        if (simulationStep <= trafficLights.length) {
          setTrafficLights(prev => 
            prev.map((light, index) => ({
              ...light,
              status: index < simulationStep ? 'green' : 'red'
            }))
          );
          
          // Trigger voice navigation
          if (simulationStep <= voiceMessages.length) {
            speakMessage(voiceMessages[simulationStep - 1]);
          }
        }
        if (simulationStep < 5) {
          setSimulationStep(prev => prev + 1);
        }
      }, 2000); // Increased to 2 seconds for better voice timing
      return () => clearTimeout(timer);
    }
  }, [simulationStep, trafficLights.length, voiceEnabled]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (speechSynthRef.current) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  const startSimulation = () => {
    setSimulationStep(1);
    if (voiceEnabled) {
      speakMessage("Emergency clearance initiated. Beginning route optimization.");
    }
  };

  const proceedToNotifications = () => {
    navigate("/notifications");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-soft border-b">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              onClick={() => navigate("/")}
              className="p-2"
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              <h1 className="text-lg font-bold text-foreground">Traffic Control</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Status Banner */}
      <div className="max-w-md mx-auto px-4 py-3">
        <div className="bg-gradient-emergency rounded-lg p-4 text-primary-foreground">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/20 rounded-lg">
                <Navigation className="h-5 w-5" />
              </div>
              <div>
                <div className="font-semibold">
                  Emergency Route Active
                </div>
                <div className="text-sm opacity-90">
                  {isPlaying ? "Voice guidance active" : "Optimizing traffic flow for emergency vehicle"}
                </div>
              </div>
            </div>
            {/* Voice Navigation Toggle */}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleVoice}
              className="text-white hover:bg-white/20 p-2"
              title={voiceEnabled ? "Disable voice navigation" : "Enable voice navigation"}
            >
              {voiceEnabled ? (
                <Volume2 className={`h-5 w-5 ${isPlaying ? 'animate-pulse' : ''}`} />
              ) : (
                <VolumeX className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Map Simulation */}
      <div className="max-w-md mx-auto px-4 pb-6 space-y-4">
        <Card className="shadow-soft">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2">
              Route Simulation
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              Traffic lights updating in real-time
            </p>
          </CardHeader>
          <CardContent>
            {/* Simulation Area */}
            <div className="relative bg-muted rounded-lg h-64 overflow-hidden">
              {/* Route Path */}
              <svg className="absolute inset-0 w-full h-full">
                <defs>
                  <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity="0.6" />
                    <stop offset="100%" stopColor="hsl(var(--secondary))" stopOpacity="0.6" />
                  </linearGradient>
                </defs>
                <path
                  d="M 20 50 Q 50 30 80 60 Q 60 80 35 70"
                  stroke="url(#routeGradient)"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  className="drop-shadow-lg"
                />
              </svg>

              {/* Traffic Lights */}
              {trafficLights.map((light) => (
                <div
                  key={light.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2"
                  style={{ left: `${light.x}%`, top: `${light.y}%` }}
                >
                  <Circle
                    className={`h-6 w-6 ${
                      light.status === 'green' 
                        ? 'text-green-500 fill-green-500' 
                        : 'text-red-500 fill-red-500'
                    } transition-colors duration-500`}
                  />
                </div>
              ))}

              {/* Emergency Vehicle */}
              <div
                className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-1000 ease-in-out"
                style={{ 
                  left: simulationStep > 0 ? `${20 + simulationStep * 15}%` : '10%', 
                  top: '50%' 
                }}
              >
                <div className="p-2 bg-gradient-emergency rounded-lg shadow-glow">
                  <Car className="h-4 w-4 text-primary-foreground" />
                </div>
              </div>
            </div>

            {/* Controls */}
            <div className="mt-4 space-y-3">
              {simulationStep === 0 ? (
                <Button
                  onClick={startSimulation}
                  className="w-full bg-gradient-emergency hover:shadow-glow"
                >
                  Start Traffic Clearance
                </Button>
              ) : simulationStep >= 4 ? (
                <Button
                  onClick={proceedToNotifications}
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                >
                  <Navigation className="mr-2 h-4 w-4" />
                  Route Cleared - View Status
                </Button>
              ) : (
                <div className="text-center">
                  <div className="text-sm font-medium text-foreground mb-2">
                    Clearing traffic lights...
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div 
                      className="bg-gradient-emergency h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${(simulationStep / 4) * 100}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Live Stats */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="shadow-soft">
            <CardContent className="p-3 text-center">
              <div className="text-xl font-bold text-green-600 mb-1">
                {trafficLights.filter(l => l.status === 'green').length}
              </div>
              <div className="text-xs text-muted-foreground">Lights Green</div>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardContent className="p-3 text-center">
              <div className="text-xl font-bold text-secondary mb-1">
                {Math.max(0, 4 - simulationStep)}s
              </div>
              <div className="text-xs text-muted-foreground">ETA</div>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardContent className="p-3 text-center">
              <div className="text-xl font-bold text-primary mb-1">
                {simulationStep >= 4 ? '100' : Math.round((simulationStep / 4) * 100)}%
              </div>
              <div className="text-xs text-muted-foreground">Complete</div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default TrafficSimulation;