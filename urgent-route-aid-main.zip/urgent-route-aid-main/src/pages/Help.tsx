import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, HelpCircle, AlertTriangle, Download, Phone, Shield, Navigation, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";

const Help = () => {
  const navigate = useNavigate();

  const downloadPDF = () => {
    // Simulate PDF download - in real app this would download actual PDF
    const link = document.createElement('a');
    link.href = '#';
    link.download = 'emergency-traffic-clearance-manual.pdf';
    link.click();
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-soft border-b">
        <div className="max-w-2xl mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              onClick={() => navigate("/dashboard")}
              className="p-2"
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <div className="flex items-center gap-2">
              <HelpCircle className="h-5 w-5 text-primary" />
              <h1 className="text-lg font-bold text-foreground">Help & Safety Instructions</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Emergency Quick Reference */}
        <Card className="shadow-soft border-l-4 border-l-primary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-primary" />
              Emergency Quick Reference
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-3 bg-primary/10 rounded-lg">
                <h4 className="font-semibold flex items-center gap-2 mb-2">
                  <Phone className="h-4 w-4" />
                  Emergency Contact
                </h4>
                <p className="text-sm text-muted-foreground">
                  Dispatch Center: <strong>911</strong><br />
                  Technical Support: <strong>1-800-TRAFFIC</strong>
                </p>
              </div>
              
              <div className="p-3 bg-secondary/10 rounded-lg">
                <h4 className="font-semibold flex items-center gap-2 mb-2">
                  <Clock className="h-4 w-4" />
                  Response Time
                </h4>
                <p className="text-sm text-muted-foreground">
                  Average: <strong>&lt;30 seconds</strong><br />
                  Maximum: <strong>60 seconds</strong>
                </p>
              </div>
            </div>
            
            <Button onClick={downloadPDF} className="w-full" variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Download PDF Manual
            </Button>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <Card className="shadow-soft">
          <CardHeader>
            <CardTitle>Frequently Asked Questions</CardTitle>
          </CardHeader>
          <CardContent>
            <Accordion type="single" collapsible className="w-full">
              <AccordionItem value="item-1">
                <AccordionTrigger>How do I request emergency traffic clearance?</AccordionTrigger>
                <AccordionContent>
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>Open the Emergency Traffic Clearance app</li>
                    <li>Tap the prominent "Request Emergency Clearance" button on the home screen</li>
                    <li>The system will automatically begin route optimization</li>
                    <li>Follow voice navigation instructions if enabled</li>
                    <li>Monitor real-time status updates in the notifications screen</li>
                  </ol>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-2">
                <AccordionTrigger>What happens during traffic clearance?</AccordionTrigger>
                <AccordionContent>
                  <p className="text-sm space-y-2">
                    The system coordinates with traffic management infrastructure to:
                  </p>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                    <li>Override traffic signals along your route</li>
                    <li>Alert other vehicles via connected systems</li>
                    <li>Provide real-time navigation guidance</li>
                    <li>Monitor your progress and adjust signals dynamically</li>
                  </ul>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-3">
                <AccordionTrigger>How does voice navigation work?</AccordionTrigger>
                <AccordionContent>
                  <div className="text-sm space-y-2">
                    <p>Voice navigation provides turn-by-turn spoken instructions including:</p>
                    <ul className="list-disc list-inside mt-2 space-y-1">
                      <li>Route clearance confirmations</li>
                      <li>Turn-by-turn directions</li>
                      <li>Traffic light status updates</li>
                      <li>Safety alerts and warnings</li>
                      <li>ETA and progress updates</li>
                    </ul>
                    <p className="mt-2">
                      <strong>Toggle:</strong> Use the volume icon in the status banner to enable/disable voice guidance.
                    </p>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-4">
                <AccordionTrigger>What if the system fails to respond?</AccordionTrigger>
                <AccordionContent>
                  <div className="text-sm space-y-2">
                    <p>If you don't receive a response within 60 seconds:</p>
                    <ol className="list-decimal list-inside mt-2 space-y-1">
                      <li>Try requesting clearance again</li>
                      <li>Check your network connection</li>
                      <li>Contact dispatch center at 911</li>
                      <li>Proceed with standard emergency protocols</li>
                    </ol>
                  </div>
                </AccordionContent>
              </AccordionItem>

              <AccordionItem value="item-5">
                <AccordionTrigger>Safety guidelines for emergency drivers</AccordionTrigger>
                <AccordionContent>
                  <div className="text-sm space-y-2">
                    <ul className="list-disc list-inside space-y-1">
                      <li><strong>Always maintain visual contact</strong> with traffic conditions</li>
                      <li><strong>Do not rely solely</strong> on automated signals</li>
                      <li><strong>Reduce speed</strong> when approaching intersections</li>
                      <li><strong>Use emergency sirens</strong> as required by local regulations</li>
                      <li><strong>Be prepared to stop</strong> if conditions are unsafe</li>
                      <li><strong>Report system malfunctions</strong> immediately to dispatch</li>
                    </ul>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </CardContent>
        </Card>

        {/* Safety Guidelines */}
        <Card className="shadow-soft border-l-4 border-l-secondary">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-secondary" />
              Safety Guidelines
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-sm">
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <h4 className="font-semibold text-red-800 mb-1">Critical Safety Notice</h4>
                <p className="text-red-700">
                  This system assists with traffic management but does not replace safe driving practices. 
                  Always maintain situational awareness and follow all traffic safety protocols.
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3 bg-muted/50 rounded-lg">
                  <h4 className="font-semibold mb-2">Before Starting</h4>
                  <ul className="text-xs space-y-1">
                    <li>• Verify emergency authorization</li>
                    <li>• Check equipment functionality</li>
                    <li>• Confirm destination in system</li>
                  </ul>
                </div>
                
                <div className="p-3 bg-muted/50 rounded-lg">
                  <h4 className="font-semibold mb-2">During Transport</h4>
                  <ul className="text-xs space-y-1">
                    <li>• Monitor voice guidance</li>
                    <li>• Watch for signal overrides</li>
                    <li>• Report any system issues</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="space-y-3">
          <Button
            onClick={() => navigate("/")}
            className="w-full bg-gradient-emergency hover:shadow-glow"
          >
            <Navigation className="mr-2 h-4 w-4" />
            Request Emergency Clearance
          </Button>
          
          <Button
            variant="outline"
            onClick={() => navigate("/dashboard")}
            className="w-full"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Help;