import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, CheckCircle, Info, AlertTriangle, Home, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

interface Notification {
  id: string;
  type: 'info' | 'warning' | 'success';
  title: string;
  description: string;
  timestamp: string;
  status: 'completed';
}

const Notifications = () => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'info',
      title: 'Emergency Request Sent',
      description: 'Alert dispatched to traffic management system',
      timestamp: '0s ago',
      status: 'completed'
    }
  ]);

  useEffect(() => {
    const notificationSequence = [
      {
        id: '2',
        type: 'info' as const,
        title: 'Traffic System Connected',
        description: 'Successfully connected to local traffic grid',
        timestamp: '2s ago',
        status: 'completed' as const
      },
      {
        id: '3',
        type: 'info' as const,
        title: 'Route Optimization Started',
        description: 'Calculating optimal emergency vehicle path',
        timestamp: '4s ago',
        status: 'completed' as const
      },
      {
        id: '4',
        type: 'warning' as const,
        title: 'Traffic Lights Override Active',
        description: 'Traffic signals updated along emergency route',
        timestamp: '7s ago',
        status: 'completed' as const
      },
      {
        id: '5',
        type: 'success' as const,
        title: 'Route Cleared Successfully',
        description: 'Emergency vehicle path is now clear',
        timestamp: '10s ago',
        status: 'completed' as const
      }
    ];

    notificationSequence.forEach((notification, index) => {
      setTimeout(() => {
        setNotifications(prev => [...prev, notification]);
      }, (index + 1) * 2000);
    });
  }, []);

  const getIconForType = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5" />;
      default:
        return <Info className="h-5 w-5" />;
    }
  };

  const getBorderColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'border-l-green-500';
      case 'warning':
        return 'border-l-secondary';
      default:
        return 'border-l-primary';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card shadow-soft border-b">
        <div className="max-w-md mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              onClick={() => navigate("/traffic-simulation")}
              className="p-2"
            >
              <ArrowLeft className="h-6 w-6" />
            </Button>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <h1 className="text-lg font-bold text-foreground">System Status</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Status Summary */}
      <div className="max-w-md mx-auto px-4 py-3">
        <div className="bg-green-600 rounded-lg p-4 text-white">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <CheckCircle className="h-5 w-5" />
            </div>
            <div>
              <div className="font-semibold">
                Emergency Clearance Active
              </div>
              <div className="text-sm opacity-90">
                Traffic successfully cleared for emergency vehicle
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Updates */}
      <div className="max-w-md mx-auto px-4 pb-6 space-y-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-1">Real-time Updates</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Live status from traffic management system
          </p>
        </div>

        <div className="space-y-3">
          {notifications.slice().reverse().map((notification) => (
            <Card key={notification.id} className={`shadow-soft border-l-4 ${getBorderColor(notification.type)} animate-slide-up`}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${
                    notification.type === 'success' ? 'bg-green-100 text-green-600' :
                    notification.type === 'warning' ? 'bg-secondary/20 text-secondary' :
                    'bg-primary/20 text-primary'
                  }`}>
                    {getIconForType(notification.type)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="font-medium text-foreground">
                        {notification.title}
                      </h3>
                      <span className="text-xs text-muted-foreground">
                        {notification.timestamp}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {notification.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* System Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-soft">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary mb-1">
                {notifications.length}
              </div>
              <div className="text-xs text-muted-foreground">Status Updates</div>
            </CardContent>
          </Card>
          <Card className="shadow-soft">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-600 mb-1">100%</div>
              <div className="text-xs text-muted-foreground">System Confirmed</div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3 pt-4">
          <Button
            onClick={() => setNotifications([])}
            variant="outline"
            className="w-full"
          >
            Clear All Notifications
          </Button>
          <Button
            onClick={() => navigate("/")}
            className="w-full bg-gradient-emergency hover:shadow-glow"
          >
            <Home className="mr-2 h-4 w-4" />
            Return to Home
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("/traffic-simulation")}
          >
            <MapPin className="mr-2 h-4 w-4" />
            View Route Map
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Notifications;